package br.com.siglabor.dao;

import br.com.siglabor.domain.Analista;

public class AnalistaDAO extends GenericDAO<Analista>{

}
