package br.com.siglabor.dao;

import br.com.siglabor.domain.Produto;

public class ProdutoDAO extends GenericDAO<Produto>{

}
