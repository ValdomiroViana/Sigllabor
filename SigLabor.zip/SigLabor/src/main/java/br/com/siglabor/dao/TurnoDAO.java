package br.com.siglabor.dao;

import br.com.siglabor.domain.Turno;

public class TurnoDAO extends GenericDAO<Turno>{

}
